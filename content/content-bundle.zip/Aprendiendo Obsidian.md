# Curso de Obsidian
[Videos](https://www.youtube.com/watch?v=q7snzrbARL4&list=PLWUX-KZsnKXSKOjd4WIbqB5GsHORz88JS&index=3)
## Colocar salto de página en PDFs
Se debe incluir este código en el texto del documento:
```
<div style="page-break-after: always;"></div>
```

https://forum.obsidian.md/t/page-breaks-for-pdfs/13107/2
